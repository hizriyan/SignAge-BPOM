<?
echo "<center>";
echo "<img src='image/logo.png' width='200' height='200'>";
echo "</center>";
?>
