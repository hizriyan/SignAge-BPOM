<?php
$video;
foreach ($linkvideo as $key) {
	if($key->idvideo=="wmhistracun"){
		$video= $key->link;
	}
}
?>


<div class="kotakvideo" >
<video width="" height="650px" autoplay id="myVideo" style="margin-left:100px; box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
  <source style="box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);" src="<?php echo $video;?>" type="video/mp4">
</video>
</div>

<script type='text/javascript'>
    document.getElementById('myVideo').addEventListener('ended',myHandler,false);
    function myHandler(e) {
        window.location.replace('<?php base_url()?>?page=eselon');
    }
</script>