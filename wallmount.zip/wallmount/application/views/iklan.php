<?php
$video;

if($linkiklan != NULL){
	foreach ($linkiklan as $key) {
		$video= $key->link;
	}

	?>
	<div class="kotakvideo" ><video width="" height="650px" autoplay id="myVideo" style="margin-left:100px; box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
		<source style="box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);" src="<?php $_SERVER['HTTP_HOST']?>/signageadmin/video/<?php echo $video;?>" type="video/mp4">
		</video>
	</div>

	<script type='text/javascript'>
	document.getElementById('myVideo').addEventListener('ended',myHandler,false);
	function myHandler(e) {
		window.location.replace('<?php base_url()?>?page=keracunan');
	}
	</script>

	<?php
	}
else{


	?>
	<div class="kotakgraph1">
		<div id="judul1">Iklan </div>
		<div id="my-div"  style="width:1200px;height: 600px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
			TIDAK ADA VIDEO UNTUK DI PUTAR 
		</div>
	</div>


	<script type='text/javascript'>
	setTimeout(function(){window.location.href='<?php base_url()?>?page=keracunan'},15000);
	</script>
	<?php
}

?>
