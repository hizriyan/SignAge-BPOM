<div class="kotakgraph1">
		<div id="cgraph"  style="width:1200px;height: 600px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
        </div>
</div>

<script>


setTimeout(function(){window.location.href='<?php base_url()?>?page=petaccdalam'},30000);

$(function () {
    // Create the chart
    $('#cgraph').highcharts({
    	chart: {
    		type: 'column'
    	},
    	credits: {
    		enabled: false
    	},
    	title: {
    		text: 'Trend Contact Center Halo BPOM 30 Hari Terakhir <br> Tanggal <?php echo date("d-M-Y",strtotime("-1 months"))." s.d ". date("d-M-Y") ?>',
            style: {"fontSize": "40px"}
    	},
    	subtitle: {
    		text: ''
    	},
    	xAxis: {
    		type: 'category'
            
    	},
    	yAxis: {
    		title: {
    			text: ''
    		}

    	},
    	legend: {
    		enabled: false
    	},
    	plotOptions: {
    		series: {
    			borderWidth: 0,
    			dataLabels: {
    				enabled: true,
                    style: {"fontSize": "15px"},
    				format: '{point.y:.f}'
    			}

    		}
    	},

    	tooltip: {
    		headerFormat: '<span style="font-size:20px">{series.name}</span><br>',
    		pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.f}</b> of total<br/>'
    	},

    	series: [{
    		name: 'Keracunan',
    		colorByPoint: true,
    		data: <?php echo json_encode($ccbulan, JSON_NUMERIC_CHECK);?>
    	}]
    });
});
</script>