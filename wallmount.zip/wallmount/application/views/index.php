<?php 
if(isset($_GET['page']))
    $page=$_GET['page'];
?>

<html>
<head>
    <title>Wallmount</title>
    <link href = "<?php echo base_url(); ?>css/metro.css" rel="stylesheet" type="text/css" />
    <link href = "<?php echo base_url(); ?>css/metro-icons.css" rel="stylesheet" type="text/css" />
    <!-- <link href = "<?php echo base_url(); ?>css/orgchart.css" rel="stylesheet" type="text/css" /> -->
    <link href = "<?php echo base_url(); ?>css/main.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url(); ?>js/jquery-1.11.3.min.js"></script>
    <script src="<?php echo base_url(); ?>js/metro.js"></script>
    <script src="<?php echo base_url(); ?>js/modernizr.js"></script>
    <script src="<?php echo base_url(); ?>js/HighCharts.js"></script>
    <script src="<?php echo base_url(); ?>js/exporting.js"></script>
    <script src="<?php echo base_url(); ?>js/jquery.Scroller-1.0.min.js" type="text/javascript"></script>
    
    
    <script>
    function doconfirm()
    {
        job=confirm("Are you sure to delete permanently?");
        if(job!=true)
        {
            return false;
        }
    }
    </script>
</head>
<body  style="overflow:hidden;background:#E99E47;">



    <?php
    if(!isset($page)){  
        $this->load->view('start');
    }
    else{
        $this->load->view(''.$page.'');
    }
    ?>

    
</body>
<script src="<?php echo base_url(); ?>/js/main.js"></script>


    </html>
