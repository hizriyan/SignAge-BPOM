<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div style="position: absolute;  top: 20px;  left: 101px;">
  <span style="font-size: 80px;  color: white;  font-family: "Open Sans";">Profile Eselon I</span>
</div>

<div style="position: relative;  left: 110px;  top: 125px;  width:1150px;  height: 600px;  box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);  background: #00AFE1;">
  <img style="position:absolute;"src="<?php echo base_url();?>image/e1.png"  onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" >
  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kbpom") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#" style="position:absolute;top:30px;left:200px;background:#DB562D; color:white; display: block;  border: 4px solid #fff;  overflow: hidden;  text-decoration: none;  font-weight: bold;  height: 140px;  width: 350px;  border-radius: 70px;  margin-bottom: -26px;  box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);  -webkit-transition: all linear .1s;  -moz-transition: all linear .1s;  transition: all linear .1s;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>"  onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" style="height: 120px;  width: 120px;  border: 4px solid #fff;  border-radius: 60px;  margin-top: 5px;  margin-left: 5px;">
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  height: 70px;  font-size: 14px;">
      <span><?php echo $jabatan;?></span>
    </div>
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  font-size: 15px;">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="subpom") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  style="position:absolute;top:170px;left:620px;background:#BC1D49; color:white; display: block;  border: 4px solid #fff;  overflow: hidden;  text-decoration: none;  font-weight: bold;  height: 140px;  width: 350px;  border-radius: 70px;  margin-bottom: -26px;  box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);  -webkit-transition: all linear .1s;  -moz-transition: all linear .1s;  transition: all linear .1s;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" style="height: 120px;  width: 120px;  border: 4px solid #fff;  border-radius: 60px;  margin-top: 5px;  margin-left: 5px;">
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  height: 70px;  font-size: 14px;">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  font-size: 15px;">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dbpptdnpdza") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  style="position:absolute;top:430px;left:20px;background:#6EB91E; color:white; display: block;  border: 4px solid #fff;  overflow: hidden;  text-decoration: none;  font-weight: bold;  height: 140px;  width: 350px;  border-radius: 70px;  margin-bottom: -26px;  box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);  -webkit-transition: all linear .1s;  -moz-transition: all linear .1s;  transition: all linear .1s;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" style="height: 120px;  width: 120px;  border: 4px solid #fff;  border-radius: 60px;  margin-top: 5px;  margin-left: 5px;">
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  height: 70px;  font-size: 14px;">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  font-size: 15px;">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dbpotkdpk") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  style="position:absolute;top:430px;left:390px;background:#633DBE; color:white; display: block;  border: 4px solid #fff;  overflow: hidden;  text-decoration: none;  font-weight: bold;  height: 140px;  width: 350px;  border-radius: 70px;  margin-bottom: -26px;  box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);  -webkit-transition: all linear .1s;  -moz-transition: all linear .1s;  transition: all linear .1s;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" style="height: 120px;  width: 120px;  border: 4px solid #fff;  border-radius: 60px;  margin-top: 5px;  margin-left: 5px;">
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  height: 70px;  font-size: 14px;">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  font-size: 15px;">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

      <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dbpkpdbb") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  style="position:absolute;top:430px;left:760px;background:#FFC708; color:white; display: block;  border: 4px solid #fff;  overflow: hidden;  text-decoration: none;  font-weight: bold;  height: 140px;  width: 350px;  border-radius: 70px;  margin-bottom: -26px;  box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);  -webkit-transition: all linear .1s;  -moz-transition: all linear .1s;  transition: all linear .1s;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" style="height: 120px;  width: 120px;  border: 4px solid #fff;  border-radius: 60px;  margin-top: 5px;  margin-left: 5px;">
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  height: 70px;  font-size: 14px;">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div style="width: 200px;  position: relative;  top: -110px;  left: 130px;  font-size: 15px;">
      <span ><?php echo $nama;?></span>
    </div>
  </a>
</div>