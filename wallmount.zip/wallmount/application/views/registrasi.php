<div class="kotakgraph1">
	<div id="judul6">Statistik Produk Yang Mendapat Persetujuan Izin Edar</div>
		<div id="my-div"  style="width:1200px;height: 500px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
			<iframe id="my-iframe6" style="margin-top:-20px;height:780;width:1366;" src="http://ceknie.pom.go.id/"></iframe>
        </div>
</div>

<script type='text/javascript'>
    setTimeout(function(){window.location.href='<?php base_url()?>?page=trencchari'},30000);
</script>