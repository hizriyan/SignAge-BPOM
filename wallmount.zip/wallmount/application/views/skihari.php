<div class="kotakgraph1">
	<div id="judul6">SKI per Hari Badan POM</div>
		<div id="my-div"  style="width:1200px;height: 500px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
			<iframe  id="iframeskihari"  src="http://e-bpom.pom.go.id"></iframe>
        </div>
</div>
<script type='text/javascript'>
    setTimeout(function(){window.location.href='<?php base_url()?>?page=skikomoditi'},60000);
</script>