<div class="kotakgraph1">
	<div id="judul6">SKI per Kantor Badan POM</div>
        <div style="background: white; width:1200px; height:550px;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4);">
		<div id="my-div2"  style="margin: 0 auto ; ">
			<iframe id="iframeskikantor" src="http://e-bpom.pom.go.id"></iframe>
        </div>
    </div>
</div>





<script type='text/javascript'>
    setTimeout(function(){window.location.href='<?php base_url()?>?page=sas'},60000);
</script>