<style>

.horizontal_scroller{
	position:relative;
	height:52px;
	width:auto;
	display:block;
	overflow:hidden;
}
.scrollingtext{
	position:absolute;
	white-space:nowrap;
	font-weight:bold;
	font-size:40px;
}
</style>

	<iframe  style="height:768px;width:1366px;" src="<?php echo base_url();?>?page=eselon"></iframe>

<div class="running-text" style="position:absolute;bottom:0px;" id="reserved">
	<div class="horizontal_scroller">
		<div class="scrollingtext"></div>
	</div>
</div>


<script type="text/javascript">
    //new mq('m1');
    
    $(document).ready(function() {
    	$('.horizontal_scroller').SetScroller({ 
    		velocity:    50,
    		direction:   'horizontal',
    		startfrom:   'right',
    		loop:        'infinite',
    		movetype:    'linear',
    		onmouseover: 'pause',
    		onmouseout:  'play',
    		onstartup:   'play',
    		cursor:      'pointer'
    	});
    	setInterval(function (){
    		$.ajax({
    			type:"POST",
    			url: "index.php/coma/runningtext",
    			async:true,
    			dataType: "json",
    			data:{},                            
    			success: function(msg){
    				if(msg.success==true){
    					$(".scrollingtext").html(msg.data);
    				}else{
    					alert(msg.message);
    				}
    			},
    		});
    	},3000);
    });
    
    </script>