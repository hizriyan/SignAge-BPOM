<div class="kotakgraph1">
	<div id="judul6">SKI per Komoditi Badan POM</div>
	<div id="my-div3"  style="width:1200px;height: 560px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
			<iframe id="iframeskikomoditi"  src="http://e-bpom.pom.go.id"></iframe>
        </div>
</div>



<script type='text/javascript'>
    setTimeout(function(){window.location.href='<?php base_url()?>?page=skikantor'},60000);
</script>