
<div class="kotakgraph1" style="width: 1150px;background:none;">
	<div id="judul1" style="width: 1150px;margin-left: 22px;">Profil Eselon I</div>
		<div id="my-div"  style="width:1200px;height: 600px; margin: 0 auto ;">
			<iframe id="my-iframe1" style="margin-top:-20px;height:780;width:1366;" src="<?php echo base_url();?>?page=eselon1wallmount" ></iframe>
        </div>
</div>


<script type='text/javascript'>
    setTimeout(function(){window.location.href='<?php base_url()?>?page=skihari'},30000);
</script>