<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Coma extends CI_Controller {

	function __construct(){
		parent::__construct();              
		$this->load->helper('url');
		$this->load->model('data_model');  
		$this->load->library('session');
	}

	public function index()
	{
		$data['runningtext']= $this->data_model->getData('runningtext');
		$data['cchari']= $this->data_model->getDatachart('cchari');
		$data['ccminggu']= $this->data_model->getDatachart('ccminggu');
		$data['ccbulan']= $this->data_model->getDatachart('ccbulan');
		$data['ccdalam']= $this->data_model->getDatachart('ccdalam');
		$data['ccluar']= $this->data_model->getDatachart('ccluar');
		$data['linkvideo']= $this->data_model->getData('wmvideo');
		$data['linkiklan']= $this->data_model->getDataIklan('wmiklan');
		$data['tabelpegawai']= $this->data_model->getData('pegawai');
		$data['alamat']= $this->data_model->get1Data('alamatgambar');
		$this->load->view('index',$data);

	}

	public function runningtext(){
		$value= $this->data_model->getData('runningtext');
		$rtext="";
		foreach ($value as $key){
			$rtext=$key->text.". ".$rtext;
		}
		if($value){
					$data = array("success"=>true,"message"=>"Success","data"=>$rtext);
		}else{
					$data = array("success"=>false,"message"=>"Failed");
		}
		echo json_encode($data);
		
	}
}

