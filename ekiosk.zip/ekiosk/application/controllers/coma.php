<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Coma extends CI_Controller {

	function __construct(){
		parent::__construct();              
		$this->load->helper('url');
		$this->load->library('session');  
		$this->load->helper('security');
		$this->load->model('data_model');
	}

	public function index()
	{
		$data['graph1']= $this->data_model->getDatachart('trend_center');
		$data['graph2']= $this->data_model->getDatachart('trend_center2');
		$data['graph3']= $this->data_model->getDatachart('trend_center3');
		$data['graph4']= $this->data_model->getDatachart('trend_center4');
		$data['tabelpegawai']= $this->data_model->getData('pegawai');
		$data['infokeracunan']= $this->data_model->getData('infokeracunan');
		$data['alamat']= $this->data_model->get1Data('alamatgambar');
		$this->load->view('index',$data);
	}

}
?>

