<?php
class Data_model extends CI_Model{

    function getData($table){
        $this->db->select("*");
        $this->db->from($table);
        if($table == 'runningtext'){
            $this->db->order_by("IDRUNNINGTEXT", "desc");
        }
        elseif ($table == 'admin') {
            $this->db->order_by("IDADMIN", "asc");
        }
        else
        {
        }
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return $query->result();
        } else {

        }
    }
    function getDatachart($table){
        $this->db->select("name,y");
        $this->db->from($table);
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return $query->result();
        } else {

        }
    }

    function get1Data($table){
        $this->db->select("*");
        $this->db->from($table);
        $query = $this->db->get();
        $this->db->limit(1);
        if($query->num_rows() > 0){
            foreach ($query->result() as $key) {
                return $key;
            }
        }
    }






}
?>
