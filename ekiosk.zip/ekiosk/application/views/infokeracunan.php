<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
foreach ($alamat as $key) {
	$linkimage=$alamat->alamat;
}
?>
<div class="positionik">
	<span class="judulik">Info Keracunan</span>
</div>




<div class="kotaktrend">
    <div id="my-div3"  style="width:760px;height: 900px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
      <iframe  id="iframe-trend" style="margin-top:-105px;height:1000px;width:760px;" src="http://spimker.pom.go.id"></iframe>
        </div>
</div>

<a href="<?php echo base_url();?>" class="homebtn" style="bottom: 110px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>
