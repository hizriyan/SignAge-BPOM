<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
$kantor;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div class="position3">
  <span class="judul">Alamat Biro</span>
</div>

<a href="<?php echo base_url();?>?page=unit" class="homebtn" style="bottom: 50px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div class="kotakchart">

<img style="position:absolute;width:600px;top:50px;left:70px;"src="<?php echo base_url();?>image/es2.png"  onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" >
  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="inspk1") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:50px;left:80px;background:#C3482F; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>
  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="bpk") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:270px;left:300px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="bkln") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:480px;left:300px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="bhkhm") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:680px;left:300px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

      <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="bu") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:880px;left:300px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>
</div>



<?php
foreach ($tabelpegawai as $key ) {
  if ($key->idjabatan=="kbpom" || $key->idjabatan=="bpk" || $key->idjabatan=="bkln" || $key->idjabatan=="bhkhm" || $key->idjabatan=="bu"|| $key->idjabatan=="inspk1") {
    $idjabatan=$key->idjabatan;
    $nama=$key->nama;
    $jabatan=$key->jabatan;
    $alamat=$key->kantor;
    $pendidikan=$key->pendidikan;
    $karir=$key->karir;
    ?>
    <div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="760">
      <div class="modalprofil">
        <div>
          <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
        </div>
        <div class="ppmnama">
          <p ><?php echo $jabatan;?></p>
        </div>
        <div class="ppmalamat">
          <span>Alamat Kantor:</br><?php echo $alamat;?></span>
        </div>
      </div>
    </div>
    <?php
  }
}
?>


<script>
function showDialog(id){
  var dialog = $(id).data('dialog');
  dialog.open();
}
</script>