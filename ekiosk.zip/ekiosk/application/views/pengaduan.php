<div class="position3">
	<span class="judul">Formulir Pengaduan</span>
</div>

<a href="<?php echo base_url();?>" class="homebtn" style="top: 40px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>




<div class="kotakgraph1">
		<div id="my-div4"  style="width:768px;height: 1100px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
			<iframe  id="my-iframe1" style="margin-top:-20px;margin-left:-20px;height:1200px;width:1366px;" src="http://ulpk.pom.go.id/ulpk/home.php?page=kontak&kontak=pengaduan"></iframe>
        </div>
</div>

<!-- <div style="position:absolute; left:600px; top:300px;">
	<input type="text" placeholder=" Enter something...">
</div> -->




<script>
var availableTags = ["ActionScript", "AppleScript", "Asp", "BASIC", "C", "C++", "Clojure",
"COBOL", "ColdFusion", "Erlang", "Fortran", "Groovy", "Haskell", "Java", "JavaScript",
"Lisp", "Perl", "PHP", "Python", "Ruby", "Scala", "Scheme" ];

$('input')
.keyboard({ layout: 'qwerty' })
.autocomplete({
	source: availableTags
})
.addAutocomplete({
	position : {
			of : null,        // when null, element will default to kb.$keyboard
			my : 'center top', // 'center top', (position under keyboard)
			at : 'center top',  // 'center bottom',
			collision: 'flip'
		}
	})
.addTyping();
</script>