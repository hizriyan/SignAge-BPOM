<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div class="position3">
  <span class="judul">Profile Deputi III Badan POM</span>
</div>
<script>
function showDialog(id){
  var dialog = $(id).data('dialog');
  dialog.open();
}
</script>
<a href="<?php echo base_url();?>?page=eselon2" class="homebtn" style="bottom: 50px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div class="kotakchart">
  

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="didsp") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:80px;left:180px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dpkp") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:280px;left:180px;background:#6EB91E; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dsdpkp") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:480px;left:180px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dspp") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:680px;left:180px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

      <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dppdbb") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:880px;left:180px;background:#57DCA9; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>
</div>



<?php
foreach ($tabelpegawai as $key ) {
  if ($key->idjabatan=="dbpkpdbb" || $key->idjabatan=="didsp" || $key->idjabatan=="dpkp" || $key->idjabatan=="dsdpkp" || $key->idjabatan=="dspp" || $key->idjabatan=="dppdbb") {
    $idjabatan=$key->idjabatan;
    $nama=$key->nama;
    $jabatan=$key->jabatan;
    $pendidikan=$key->pendidikan;
    $karir=$key->karir;
    $alamat=$key->kantor;
    ?>
    <div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="760">
      <div class="modalprofil">
        <div>
          <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
        </div>
        <div class="ppmnama">
          <p ><?php echo $nama;?></p>
        </div>
        <div class="ppmjabatan">
          <span><?php echo $jabatan;?></span>
        </div>
        <div class="dtlpddk">
          <div style="overflow-y:auto; width 430; height:420px;">
            <p class="centerfont">Pendidikan</p>
            <div style="background:white;padding:10px;">
              <?php echo $pendidikan;?>
            </div>
            <p class="centerfont">Karir</p>
            <div style="background:white; padding:10px;">
              <?php echo $karir;?>
            </div>
            <p class="centerfont">Alamat</p>
            <div style="background:white; padding:10px;">
              <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="ppalamat" >
            </div>
            <div style="background:white; padding:10px;">
              <?php echo $alamat;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
  }
}
?>


