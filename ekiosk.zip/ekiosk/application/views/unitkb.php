<div class="position31">
  <span class="judulalamat">Alamat Group </br>Balai Besar / Balai POM</span>
</div>

<a href="<?php echo base_url();?>" class="homebtn" style="top: 40px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div class="position2">
  <div class="grid">
    <div class="row cells3">
      <div class="cell">
        <a href="?page=unitsumatera" style="color: #000">
          <div class="tile-wide tile-wide-y" data-role="tile" style="background:#613DBC;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/g1.png" style="position:absolute;width: 150px;height:150px; top:60px;left:80px;"></img>
              <span class="tile-label" style="font-size:20px;font-weight:bold;color:white;">Sumatera</span>
            </div>
          </div>
        </a>
      </div>
      <div class="cell">
        <a href="?page=unitjawa" style="color: #000">
          <div class="tile-wide" data-role="tile" style="background:#2777EC;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/g1.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label" style="font-size:20px;font-weight:bold;color:white;">Jawa</span>
            </div>

          </div>
        </a>
        <a href="?page=unitkalimantan" style="color: #000">
          <div class="tile-wide" data-role="tile" style="background:#B01A40;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/g2.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label" style="font-size:20px;font-weight:bold;color:white;">Kalimantan</span>
            </div>
          </div>
        </a>
      </div>
      <div class="cell">
        <a href="?page=unitsulawesi" style="color: #000">
          <div class="tile-wide" data-role="tile" style="background:#009218;"> 
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/g2.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label" style="font-size:20px;font-weight:bold;color:white;">Sulawesi</span>
            </div>
          </div>
        </a>
        <a href="?page=unitbalitimur" style="color: #000">
          <div class="tile-wide" data-role="tile" style="background:#D74F29;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/g2.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label" style="font-size:20px;font-weight:bold;color:white;">Bali dan Indonesia Timur</span>
            </div>
          </div>
        </a>
      </div>
    </div>
  </div>

</div>