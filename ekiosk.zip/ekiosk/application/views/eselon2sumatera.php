<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div class="position36">
  <span class="judulalamat">Profile Eselon II BPOM di Wilayah Sumatera</span>
</div>
<script>
function showDialog(id){
  var dialog = $(id).data('dialog');
  dialog.open();
}
</script>


<div class="kotakchart" style="top:200px;">

  <div class="cell">
    <div id="car_m_1" class="carousel" data-role="carousel" data-height="1100" data-width="700" data-controls="false" data-markers="false" data-auto="false" style="width: 745; height: 450px;">
      <div class="slide" style="display: block; ">


       <?php
       foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpaceh") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile" style="position:absolute;top:120px;left:180px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppekanbaru") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile" style="position:absolute;top:280px;left:180px;background:#6EB91E; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppadang") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:440px;left:180px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpmedan") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:600px;left:180px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpbatam") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:760px;left:180px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>



    </div>
    <div class="slide" style="display: block; ">

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpjambi") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:120px;left:180px;background:#57DCA9; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppalembang") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:280px;left:180px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kplampung") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:440px;left:180px;background:#6EB91E; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpbengkulu") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:600px;left:180px;background:#633DBE; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppinang") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile" style="position:absolute;top:760px;left:180px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>
    </div>
  </div>
</div>

<a href="<?php echo base_url();?>?page=eselon2kb" class="homebtn" style="bottom: 50px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>




</div>
<div style="position:absolute;bottom:180px;left:300px; display: inline-block; ">
  <a id="prev" href="#" class="homebtn" style="top: 0px;left: 0px;" onclick="$('#car_m_1').data('carousel').priorSlide();"><img src="<?php echo base_url(); ?>image/icon/prev.png" style="width:50px;margin-top:6px;margin-left:0px;"></a>
  <a id="next" href="#" class="homebtn" style="top: 0px;left: 100px;" onclick="$('#car_m_1').data('carousel').nextSlide();"><img src="<?php echo base_url(); ?>image/icon/next.png" style="width:50px;margin-top:6px;margin-left:10px;"></a>
</div>


<?php
foreach ($tabelpegawai as $key ) {
  if ($key->idjabatan=="kpaceh" || $key->idjabatan=="kppekanbaru" || $key->idjabatan=="kppadang" || $key->idjabatan=="kpmedan" || $key->idjabatan=="kpbatam" || $key->idjabatan=="kpjambi" || $key->idjabatan=="kppalembang" || $key->idjabatan=="kplampung" || $key->idjabatan=="kpbengkulu" || $key->idjabatan=="kppinang" ) {
    $idjabatan=$key->idjabatan;
    $nama=$key->nama;
    $jabatan=$key->jabatan;
    $pendidikan=$key->pendidikan;
    $karir=$key->karir;
    $alamat=$key->kantor;
    ?>
    <div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="760">
      <div class="modalprofil">
        <div>
          <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
        </div>
        <div class="ppmnama">
          <p ><?php echo $nama;?></p>
        </div>
        <div class="ppmjabatan">
          <span><?php echo $jabatan;?></span>
        </div>
        <div class="dtlpddk">
          <div style="overflow-y:auto; width 430; height:420px;">
            <p class="centerfont">Pendidikan</p>
            <div style="background:white;padding:10px;">
              <?php echo $pendidikan;?>
            </div>
            <p class="centerfont">Karir</p>
            <div style="background:white; padding:10px;">
              <?php echo $karir;?>
            </div>
            <p class="centerfont">Alamat</p>
            <div style="background:white; padding:10px;">
              <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="ppalamat" >
            </div>
            <div style="background:white; padding:10px;">
              <?php echo $alamat;?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
  }
}
?>


