<script type="text/javascript">
function dialing(){
	$.ajax({
   type: "POST",
   url: "dialingscript/ast.php",
   async: false,
   dataType: "html",
   success: function(msg){

   }
 });
}
</script>
<img src="<?php echo base_url(); ?>image/logo2.png" class="logo"style="position:absolute;top:150px;left:100px;width:120px;height:120px;"></img>
<div class="position34" style="display: inline-block;">
</br>
<span class="judulstart">Badan POM</span></br>
<span class="judulstartlower">&nbsp;Badan Pengawas Obat dan Makanan</span>
</div>

<a href="#" class="katokcom" onclick="dialing()">
  <p style="color:white;margin-left:15px; font-weight:bold;">CALL HALO BPOM<img style="margin-left:40px;height:28px;" src="<?php echo base_url(); ?>image/icon/Call.png"></img></p>
</a>
<a href="?page=pengaduan" class="kotakcom">
  <p style="color:white;margin-left:15px; font-weight:bold;">FORM PENGADUAN<img style="margin-left:20px;height:25px;" src="<?php echo base_url(); ?>image/icon/Mail.png"></img></p>
</a>

<div class="position1">
  <div class="grid">
    <div class="row cells3">
      <div class="cell">
        <a href="?page=visimisi" style="color: #fff; font-weight:bold;">
          <div class="tile-wide tile-wide-y" style="background:#3387EA;" data-role="tile">
            <div class="tile-content">
              <span style="position:absolute;width: 100px;height:100px; left:20px;"><h1 style="font-size:90px;">Visi</br><small>&nbsp;&nbsp;&nbsp;&nbsp;dan</small></br>&nbsp;&nbsp;&nbsp;&nbsp;Misi</h1></span>
              <span class="tile-label">Visi, Misi, Budaya dan Struktur Organisasi Badan POM</span>
            </div>
          </div>
        </a>
      </div>
      <div class="cell">
        <a href="?page=eselon1" style="color: #fff; font-weight:bold;">
          <div class="tile-wide" data-role="tile" style="background:#CBA045;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/leader.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label">Profile Eselon I Badan POM</span>
            </div>

          </div>
        </a>
        <a href="?page=eselon2" style="color: #fff; font-weight:bold;">
          <div class="tile-wide" data-role="tile" style="background:#D3573F;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/Employee.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label"> Profile Eselon II Badan POM</span>
            </div>
          </div>
        </a>
      </div>
      
    </div>
  </div>
  <div class="grid">
    
      <div class="cell">
        <a href="?page=trend" style="color: #fff; font-weight:bold;">
          <div class="tile-wide" data-role="tile" style="background:#86A73E;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/Graph.png" style="position:absolute;width: 100px;height:100px; top:20px;left:100px;"></img>
              <span class="tile-label">Cek BPOM</span>
            </div>
          </div>
        </a>
      </div>
      <div class="cell">
        <a href="?page=infoski" style="color: #fff; font-weight:bold;">
          <div class="tile" data-role="tile" style="background:#2D9589;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/info.png" style="position:absolute;width: 100px;height:100px; top:20px;left:25px;"></img>
              <span class="tile-label">INSW</span>
            </div>
          </div>
        </a>
      </div>
      <div class="cell"  style="margin-left:-145px;">
        <a href="?page=infokeracunan" style="color: #fff; font-weight:bold;">
          <div class="tile" data-role="tile" style="background:#141E35;">
            <div class="tile-content">
              <img src="<?php echo base_url(); ?>image/icon/logoinfokeracunan.png" style="position:absolute;width: 130px;height:100px; top:20px;left:10px;"></img>
              <span class="tile-label">Info Keracunan</span>
            </div>
          </div>
        </a>
      </div>

    </div>
  </div>
  
</div>