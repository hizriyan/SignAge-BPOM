<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
foreach ($alamat as $key) {
	$linkimage=$alamat->alamat;
}
?>

<div class="position33">
	<span class="judulalamat">ALAMAT </br>BALAI BESAR / BALAI POM</span>
</div>




<img id="indo" src="<?php echo base_url(); ?>image/peta-indonesia.png"  onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" style="position:absolute; width:700px;top:250px;left:30px;" > 

<div class="position1" style="top:550px;">
	<div class="grid">
		<div class="row cells3">
			<div class="cell">
				<div class="tile-wide bg-pink" data-role="tile" onclick="change('sumatera');showDialog('#sumatera')" style="color: #fff; font-weight:bold;">
					<div class="tile-content" >
						<span class="tile-label">Sumatera</span>
					</div>
				</div>
				<div class="tile-wide bg-cobalt" data-role="tile" onclick="change('kalimantan');showDialog('#kalimantan')" style="color: #fff; font-weight:bold;">
					<div class="tile-content">
						<span class="tile-label">Kalimantan</span>
					</div>
				</div>
			</div>
			<div class="cell">
				<div class="tile-wide bg-red" data-role="tile" onclick="change('jawa');showDialog('#jawa')" style="color: #fff; font-weight:bold;">
					<div class="tile-content">
						<span class="tile-label">Jawa</span>
					</div>
				</div>
				<div class="tile-wide bg-orange" data-role="tile" onclick="change('sulawesi');showDialog('#sulawesi')" style="color: #fff; font-weight:bold;">
					<div class="tile-content">
						<span class="tile-label">Sulawesi</span>
					</div>
				</div>
			</div>

		</div>
	</div>
	<div class="grid" style="margin-left:160px;">
		<div class="row cells3">
			<div class="cell">
				<div class="tile-wide bg-green" data-role="tile" onclick="change('balidantimur');showDialog('#balidantimur')" style="color: #fff; font-weight:bold;">
					<div class="tile-content">
						<span class="tile-label">Bali dan Indonesia Timur</span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<a href="<?php echo base_url();?>" class="homebtn" style="bottom: 80px;right: 90px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div style="peta" data-role="dialog" id="sumatera" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="false" data-overlay="true" data-height="300" data-width="760">
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpaceh") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:20px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Banda Aceh</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppekanbaru") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:20px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Pekanbaru</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppadang") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:20px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Padang</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpmedan") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:270px;left:20px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Medan</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpbatam") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:360px;left:20px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Batam</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpjambi") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:370px;background:#57DCA9; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Jambi</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppalembang") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:370px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Palembang</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kplampung") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:370px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Lampung</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpbengkulu") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:270px;left:370px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Bengkulu</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppinang") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:360px;left:370px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Pangkal Pinang</span>
		</div>
	</a>

</div>
<div style="peta"data-role="dialog" id="jawa" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="false" data-overlay="true" data-height="300" data-width="760">
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpjakarta") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:20px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Jakarta</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpbandung") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:20px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Bandung</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpyogya") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:20px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Yogyakarta</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpserang") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:370px;background:#57DCA9; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Serang</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpsemarang") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:370px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Semarang</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpsurabaya") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:370px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Surabaya</span>
		</div>
	</a>
</div>
<div style="peta"data-role="dialog" id="kalimantan" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="false" data-overlay="true" data-height="300" data-width="760">
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppontianak") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:200px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Pontianak</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpsamarinda") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:200px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Samarinda</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppalangkaraya") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:200px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Palangkaraya</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpbanjarmasin") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:270px;left:200px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Banjarmasin</span>
		</div>
	</a>
</div>
<div style="peta"data-role="dialog" id="sulawesi" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="false" data-overlay="true" data-height="300" data-width="760">
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpmanado") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:20px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Manado</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kppalu") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:20px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Palu</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpgorontalo") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:200px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Gorontalo</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpmakassar") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:370px;background:#57DCA9; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Makassar</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpkendari") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:370px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Kendari</span>
		</div>
	</a>
</div>
<div style="peta"data-role="dialog" id="balidantimur" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="false" data-overlay="true" data-height="300" data-width="760">
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpdenpasar") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:20px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Denpasar</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpkupang") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:20px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Kupang</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpmataram") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:180px;left:200px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Mataram</span>
		</div>
	</a>

	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpambon") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:0px;left:370px;background:#57DCA9; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Ambon</span>
		</div>
	</a>
	<?php
	foreach ($tabelpegawai as $key) {
		if ($key->idjabatan=="kpjayapura") {
			$idjabatan=$key->idjabatan;
		}
	}
	?>
	<a href="#"  class="miniprofile2" style="position:absolute;top:90px;left:370px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
		<div class="namakota">
			<span >Jayapura</span>
		</div>
	</a>
</div>

<?php
foreach ($tabelpegawai as $key ) {
	if ($key->idjabatan=="kpjakarta" || $key->idjabatan=="kpbandung" || $key->idjabatan=="kpyogya" || $key->idjabatan=="kpserang" || $key->idjabatan=="kpsemarang" || $key->idjabatan=="kpsurabaya"||$key->idjabatan=="kpdenpasar" || $key->idjabatan=="kpkupang" || $key->idjabatan=="kpmataram" || $key->idjabatan=="kpambon" || $key->idjabatan=="kpjayapura"||$key->idjabatan=="kpmanado" || $key->idjabatan=="kppalu" || $key->idjabatan=="kpgorontalo" || $key->idjabatan=="kpmakassar" || $key->idjabatan=="kpkendari" || $key->idjabatan=="kpaceh" || $key->idjabatan=="kppekanbaru" || $key->idjabatan=="kppadang" || $key->idjabatan=="kpmedan" || $key->idjabatan=="kpbatam" || $key->idjabatan=="kpjambi" || $key->idjabatan=="kppalembang" || $key->idjabatan=="kplampung" || $key->idjabatan=="kpbengkulu" || $key->idjabatan=="kppinang" || $key->idjabatan=="kpsamarinda" || $key->idjabatan=="kppontianak" || $key->idjabatan=="kppalangkaraya" || $key->idjabatan=="kpbanjarmasin") {
		$idjabatan=$key->idjabatan;
		$nama=$key->nama;
		$jabatan=$key->jabatan;
		$pendidikan=$key->pendidikan;
		$karir=$key->karir;
		$alamat=$key->kantor;
		?>
		<div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="760">
			<div class="modalprofil">
				<div>
					<img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
				</div>
				<div class="ppmnama">
					<p >Badan <?php echo substr($jabatan,6);?></p>
				</div>
				<div class="ppmalamat">
					<span>Alamat Kantor:</br><?php echo $alamat;?></span>
				</div>
			</div>
		</div>
		<?php
	}
}
?>
<script>

function change(loc) {
	var image = document.getElementById('indo');
	image.src = "<?php echo base_url(); ?>image/"+loc+".png";
}
function showDialog(id){
	var dialog = $(id).data('dialog');
	dialog.open();
}
</script>