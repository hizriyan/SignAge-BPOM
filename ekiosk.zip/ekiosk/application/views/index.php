<?php 
if(isset($_GET['page']))
    $page=$_GET['page'];
?>
<?php header('Access-Control-Allow-Origin: *'); ?>
<html>
<head>
    <title>Ekiosk</title>
</head>
<body  style="background:url(<?php echo base_url(); ?>image/bg12.jpg);background-size: cover;  background-repeat: no-repeat;  ">

    <link href = "<?php echo base_url(); ?>css/metro.css" rel="stylesheet" type="text/css" />
    <link href = "<?php echo base_url(); ?>css/metro-icons.css" rel="stylesheet" type="text/css" />
    <link href = "<?php echo base_url(); ?>css/orgchart.css" rel="stylesheet" type="text/css" />
    <link href = "<?php echo base_url(); ?>css/main.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url(); ?>js/jquery-1.11.3.min.js"></script>
    <script src="<?php echo base_url(); ?>js/metro.js"></script>
    <script src="<?php echo base_url(); ?>js/modernizr.js"></script>
    <script src="<?php echo base_url(); ?>js/HighCharts.js"></script>
    

    <script>
    function doconfirm()
    {
        job=confirm("Are you sure to delete permanently?");
        if(job!=true)
        {
            return false;
        }
    }
    </script>

    <div id ="aa" class="container">

        <!--HEAD-->
        <?php
        


        if(!isset($page)){  
            $this->load->view('start');
        }
        else if($page=="pengaduan"){
            ?>
            <script src="<?php echo base_url(); ?>js/jquery.keyboard.js"></script>
            <script src="<?php echo base_url(); ?>js/jquery.keyboard.extension-typing.js"></script>
            <script src="<?php echo base_url(); ?>js/jquery.mousewheel.js"></script>
            <script src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
            
            <link href = "<?php echo base_url(); ?>css/keyboard.css" rel="stylesheet" type="text/css" />
            <link href = "<?php echo base_url(); ?>css/jquery-ui.css" rel="stylesheet" type="text/css" />
            <?php
            $this->load->view(''.$page.'');
        }
        else{
            $this->load->view(''.$page.'');
        }
        ?>

    </div>


</body>
<script src="<?php echo base_url(); ?>/js/main.js"></script>

</html>
