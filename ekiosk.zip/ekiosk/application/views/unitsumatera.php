<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
$kantor;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div class="position3">
  <span class="judulalamat">Alamat Eselon II Sumatera</span>
</div>

<a href="<?php echo base_url();?>?page=unitkb" class="homebtn" style="top: 40px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div class="kotakchart">

  <div class="cell">
    <div id="car_m_1" class="carousel" data-role="carousel" data-height="600" data-width="1150" data-controls="false" data-markers="false" data-auto="false" style="width: 745; height: 450px;">
      <div class="slide" style="display: block; ">


       <?php
       foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpaceh") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile" style="position:absolute;top:70px;left:100px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppekanbaru") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile" style="position:absolute;top:70px;left:700px;background:#6EB91E; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppadang") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:230px;left:100px;background:#E66121; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpmedan") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:230px;left:700px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpbatam") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:390px;left:700px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpjambi") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:390px;left:100px;background:#57DCA9; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>


    </div>
    <div class="slide" style="display: block; ">
      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppalembang") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:100px;left:150px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kplampung") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:100px;left:650px;background:#6EB91E; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kpbengkulu") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile " style="position:absolute;top:350px;left:650px;background:#633DBE; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>

      <?php
      foreach ($tabelpegawai as $key) {
        if ($key->idjabatan=="kppinang") {
          $idjabatan=$key->idjabatan;
          $nama=$key->nama;
          $jabatan=$key->jabatan;
        }
      }
      ?>
      <a href="#"  class="miniprofile" style="position:absolute;top:350px;left:150px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
        <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
        <div class="ppjabatan">
          <span ><?php echo $jabatan;?></span>
        </div>
        <div class="ppname">
          <span ><?php echo $nama;?></span>
        </div>
      </a>
    </div>
  </div>
</div>






</div>
<div style="position:absolute;top:650px;left:400px; display: inline-block; ">
  <a id="prev" href="#" class="homebtn" style="top: -20px;left: 200px;" onclick="$('#car_m_1').data('carousel').priorSlide();"><img src="<?php echo base_url(); ?>image/icon/prev.png" style="width:50px;margin-top:6px;margin-left:0px;"></a>
  <a id="next" href="#" class="homebtn" style="top: -20px;left: 300px;" onclick="$('#car_m_1').data('carousel').nextSlide();"><img src="<?php echo base_url(); ?>image/icon/next.png" style="width:50px;margin-top:6px;margin-left:10px;"></a>
</div>


<?php
foreach ($tabelpegawai as $key ) {
  if ($key->idjabatan=="kpaceh" || $key->idjabatan=="kppekanbaru" || $key->idjabatan=="kppadang" || $key->idjabatan=="kpmedan" || $key->idjabatan=="kpbatam" || $key->idjabatan=="kpjambi" || $key->idjabatan=="kppalembang" || $key->idjabatan=="kplampung" || $key->idjabatan=="kpbengkulu" || $key->idjabatan=="kppinang" ) {
    $idjabatan=$key->idjabatan;
    $nama=$key->nama;
    $jabatan=$key->jabatan;
    $pendidikan=$key->pendidikan;
    $karir=$key->karir;
    $alamat=$key->kantor;
    ?>
    <div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="800">
      <div class="modalprofil">
        <div>
          <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
        </div>
        <div class="ppmnama">
          <p ><?php echo $nama;?></p>
        </div>
        <div class="ppmjabatan">
          <span><?php echo $jabatan;?></span>
        </div>
        <div class="ppmalamat">
          <span>Alamat Kantor:</br><?php echo $alamat;?></span>
        </div>
      </div>
    </div>
    <?php
  }
}
?>


<script>
function showDialog(id){
  var dialog = $(id).data('dialog');
  dialog.open();
}
</script>