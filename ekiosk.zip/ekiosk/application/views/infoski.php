<div class="position3">
  <span class="judul">INSW</span>
</div>


<a href="<?php echo base_url();?>" class="homebtn" style="bottom: 530px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div class="kotaktrend" style="height:500px;">
    <div id="my-div3"  style="width:760px;height: 400px; margin: 0 auto ;box-shadow: 4px 4px 9px -4px rgba(0,0,0,0.4); ">
      <iframe  id="iframe-trend" style="margin-top:-105px;height:500px;width:760px;" src="http://apps1.insw.go.id"></iframe>
        </div>
</div>