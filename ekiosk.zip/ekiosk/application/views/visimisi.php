
<div class="kotakluar">
	<div class="cell">
		<div id="car_m_1" class="carousel" data-role="carousel" data-height="1100" data-width="700" data-controls="false" data-markers="false" data-auto="false" style="width: 745; height: 450px;">
			<div class="slide" style="display: block; ">
				<div class="kotakvisi">
					<div class="headerv">
						<p><center>VISI</center></p>
					</div>
					<div class="isiv">
						<p><center>Obat dan Makanan Aman Meningkatkan Kesehatan Masyarakat dan Daya Saing Bangsa.</center></p>
					</div>
				</div>
				<div class="kotakmisi">
					<div class="headerm">
						<p><center>MISI</center></p>
					</div>
					<div class="isim">
						<ul>
							<li>Meningkatkan sistem pengawasan Obat dan Makanan berbasis risiko untuk melindungi masyarakat</li>
							<li>Mendorong kemandirian pelaku usaha dalam memberikan jaminan keamanan Obat dan Makanan serta memperkuat kemitraan dengan pemangku kepentingan.</li>
							<li>Meningkatkan kapasitas kelembagaan BPOM.</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="slide" style="display: block; ">
				<div class="kotakbudaya">
					<div class="headbud">
						<p><center>Budaya Organisasi</center></p>
					</div>
					<div class="isibud">
						<p>Profesional</p>

						<ul>
							<li>Menegakkan profesionalisme dengan integritas, objektivitas, ketekunan dan komitmen yang tinggi.</li>
						</ul>

						<p>Integritas</p>

						<ul>
							<li>konsistensi dan keteguhan yang tak tergoyahkan dalam menjunjung tinggi nilai-nilai luhur dan keyakinan</li>
						</ul>

						<p>Kredibilitas</p>

						<ul>
							<li>Dapat dipercaya dan diakui oleh masyarakat luas, nasional dan internasional.</li>
						</ul>

						<p>Kerjasama Tim</p>

						<ul>
							<li>Mengutamakan keterbukaan, saling percaya dan komunikasi yang baik.</li>
						</ul>

						<p>Inovatif</p>

						<ul>
							<li>Mampu melakukan pembaruan sesuai ilmu pengetahuan dan teknologi terkini.</li>
						</ul>

						<p>Responsif/Cepat Tanggap</p>

						<ul>
							<li>Antisipatif dan responsif dalam mengatasi masalah.</li>
						</ul>

						<p>&nbsp;</p>

					</div>
				</div>
			</div>
			<div class="slide" style="display: block; ">
				<div class="kotakstruktur">
					<div class="headorga">
						<p><center>Struktur Organisasi</center></p>
					</div>
					<div class="kotakorga" id="imageorga">
						<img src="<?php echo base_url(); ?>image/orga_in.png" style="position:absolute;left:0px;width: 650px;"></img>
					</div>
				</div>
			</div>
		</div>
	</div>
	
</div>

<div style="position:absolute;bottom:150px;left:300px; display: inline-block; ">
	<a id="prev" href="#" class="homebtn" style="top: 0px;left: 0px;" onclick="$('#car_m_1').data('carousel').priorSlide();"><img src="<?php echo base_url(); ?>image/icon/prev.png" style="width:50px;margin-top:6px;margin-left:0px;"></a>
	<a id="next" href="#" class="homebtn" style="top: 0px;left: 100px;" onclick="$('#car_m_1').data('carousel').nextSlide();"><img src="<?php echo base_url(); ?>image/icon/next.png" style="width:50px;margin-top:6px;margin-left:10px;"></a>
</div>
<a href="<?php echo base_url();?>" class="homebtn" style="bottom:80px;right: 130px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<script>
$position=0;
function up() {
	if($position!=0){
		var elmnt = document.getElementById("imageorga");
		$position=$position-150;
		elmnt.scrollTop = $position;	
	}
}
function down() {
	if($position!=(5*150)){
		var elmnt = document.getElementById("imageorga");
		$position=$position+150;
		elmnt.scrollTop = $position;	
	}
	
}
</script>