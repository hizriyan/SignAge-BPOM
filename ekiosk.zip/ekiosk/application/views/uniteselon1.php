<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
$kantor;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div class="position3">
  <span class="judul">Alamat Unit Kerja Eselon I</span>
</div>



<div class="kotakchart" style="top:200px;">
  <img style="position:absolute;width:650px;left:50px;top:20px;"src="<?php echo base_url();?>image/es1.png"  onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" >
  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kbpom") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:30px;left:60px;background:#DB562D; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>"  onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="subpom") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:260px;left:250px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dbpptdnpdza") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:490px;left:320px;background:#6EB91E; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dbpotkdpk") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:690px;left:320px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

      <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="dbpkpdbb") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:890px;left:320px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>
</div>

<a href="<?php echo base_url();?>?page=unit" class="homebtn" style="bottom: 80px;left: 50px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<?php
foreach ($tabelpegawai as $key ) {
  if ($key->idjabatan=="kbpom" || $key->idjabatan=="subpom" || $key->idjabatan=="dbpptdnpdza" || $key->idjabatan=="dbpotkdpk" || $key->idjabatan=="dbpkpdbb") {
    $idjabatan=$key->idjabatan;
    $nama=$key->nama;
    $jabatan=$key->jabatan;
    $pendidikan=$key->pendidikan;
    $karir=$key->karir;
    $alamat=$key->kantor;
    ?>
    <div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="760">
      <div class="modalprofil">
        <div>
          <img src="<?php echo $linkimage.''.$idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
        </div>
        <div class="ppmnama">
          <p ><?php echo $jabatan;?></p>
        </div>
        <div class="ppmalamat">
          <span>Alamat Kantor:</br><?php echo $alamat;?></span>
        </div>
        </div>
      </div>
    </div>
    <?php
  }
}
?>


<script>
function showDialog(id){
  var dialog = $(id).data('dialog');
  dialog.open();
}
</script>