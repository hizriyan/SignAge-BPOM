<?php
$nama;
$jabatan;
$idjabatan;
$pendidikan;
$karir;
$kantor;
foreach ($alamat as $key) {
  $linkimage=$alamat->alamat;
}
?>
<div class="position3">
  <span class="judulalamat">Alamat Eselon II Daerah Sulawesi</span>
</div>

<a href="<?php echo base_url();?>?page=unitkb" class="homebtn" style="top: 40px;right: 100px;"><img src="<?php echo base_url(); ?>image/icon/back.png" style="width:50px;margin-top:4px;margin-left:5px;"></a>

<div class="kotakchart">
  

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kpmanado") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:70px;left:100px;background:#BC1D49; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kppalu") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile" style="position:absolute;top:70px;left:700px;background:#6EB91E; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kpgorontalo") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:230px;left:400px;background:#633DBE; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

  <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kpmakasar") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:390px;left:700px;background:#FFC708; color:white;" onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>

      <?php
    foreach ($tabelpegawai as $key) {
      if ($key->idjabatan=="kpkendari") {
        $idjabatan=$key->idjabatan;
        $nama=$key->nama;
        $jabatan=$key->jabatan;
      }
    }
    ?>
  <a href="#"  class="miniprofile " style="position:absolute;top:390px;left:100px;background:#57DCA9; color:white;"onclick="showDialog('#<?php echo $idjabatan;?>')">
    <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="iconpp">
    <div class="ppjabatan">
      <span ><?php echo $jabatan;?></span>
    </div>
    <div class="ppname">
      <span ><?php echo $nama;?></span>
    </div>
  </a>
</div>



<?php
foreach ($tabelpegawai as $key ) {
  if ($key->idjabatan=="kpmanado" || $key->idjabatan=="kppalu" || $key->idjabatan=="kpgorontalo" || $key->idjabatan=="kpmakasar" || $key->idjabatan=="kpkendari") {
    $idjabatan=$key->idjabatan;
    $nama=$key->nama;
    $jabatan=$key->jabatan;
    $pendidikan=$key->pendidikan;
    $karir=$key->karir;
    $alamat=$key->kantor;
    ?>
    <div data-role="dialog" id="<?php echo $idjabatan;?>" data-close-button="true"  data-overlay-color="bgmodal" data-overlay-click-close="true" data-overlay="true" data-height="600" data-width="800">
      <div class="modalprofil">
        <div>
          <img src="<?php echo $linkimage.''.$idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="pp" >
        </div>
        <div class="ppmnama">
          <p ><?php echo $nama;?></p>
        </div>
        <div class="ppmjabatan">
          <span><?php echo $jabatan;?></span>
        </div>
        <div class="ppmalamat">
          <span>Alamat Kantor:</br><?php echo $alamat;?></span>
        </div>
      </div>
    </div>
    <?php
  }
}
?>


<script>
function showDialog(id){
  var dialog = $(id).data('dialog');
  dialog.open();
}
</script>