#!/usr/bin/php -q
<?php
set_time_limit(30);
require_once("phpagi/phpagi-asmanager.php");
//$asm = new AGI_AsteriskManager();
//$asm = new AGI_AsteriskManager("/etc/asterisk/phpagi.conf","");

$asm = new AGI_AsteriskManager();

//[dialing-kiosk]
//exten => _XXXX,1,Dial(SIP/${EXTEN},,tT);

$myext="8028";
$name="doris";
$prefix="9";
$huntgroup="3000";
$context="dialing-kiosk";

$asm->connect("172.16.0.3","ecentrix","ecx1234");
$asm->send_request('Originate', array('Channel'=> 'SIP/'.$myext, 'Context' => $context, 'Priority' => 1, 'Async' => true,'callerid'=>$name,'Exten'=>$prefix.$huntgroup,'Callerid'=>$myext));
$asm->disconnect();
?>


