<?php
class Data_model extends CI_Model{

    function getData($table){
        $this->db->select("*");
        $this->db->from($table);
        if($table == 'runningtext'){
            $this->db->order_by("IDRUNNINGTEXT", "desc");
        }
        elseif ($table == 'admin') {
            $this->db->order_by("NAMA", "asc");
        }
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return $query->result();
        } else {

        }
    }
    function getDatachart($table){
        $this->db->select("name,y");
        $this->db->from($table);
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return $query->result();
        } else {

        }
    }
    function checkData($table,$user,$pass){
        $this->db->select("*");
        $this->db->from($table);
        $this->db->where("USERNAME",$user);
        $this->db->where("PASSWORD",md5($pass));
        $query = $this->db->get();
        if($query->num_rows() > 0){
            return true;
        } else {
            return false;
        }
    }
    function changeData($table,$data){
        $this->db->select("*");
        $this->db->from($table);
        if($table == 'runningtext'){
            $this->db->order_by("IDRUNNINGTEXT", "desc");
        }
        elseif ($table == 'admin') {
            $this->db->order_by("IDADMIN", "asc");
        }
        else
        {

        }
        $this->db->limit(1);
        return $this->db->update($table, $data);
    }

    function edit($table, $id,$data){
        if($table == 'pegawai'){
            $this->db->where('IDJABATAN',$id);
        }
        else{

        }
        return $this->db->update($table, $data);
    }

    function post($table, $data){
        return $this->db->insert($table, $data);
    }
    function delete($table, $id){
        if($table == 'runningtext'){
            $this->db->where('IDRUNNINGTEXT',$id);
        }
        elseif ($table == 'admin') {
            $this->db->where('IDADMIN',$id);
        }
        elseif ($table == 'infokeracunan') {
            $this->db->where('IDKERACUNAN',$id);
        }
        elseif ($table == 'wmiklan') {
            $this->db->where('IDIKLAN',$id);
        }
        return $this->db->delete($table);
    }
    function login($table,$data,$password)
    {
        $password = md5($password);
        $this -> db -> select('*');
        $this -> db -> from($table);
        $this -> db -> where('USERNAME', $data);
        $this -> db -> where('PASSWORD', $password);
        $this -> db -> limit(1);
        $query = $this -> db -> get();
        if($query -> num_rows() == 1)
        {
            return $query->result();
        }
        else
        {
            return false;

        }
    }
}
?>
