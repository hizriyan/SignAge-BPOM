<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Coma extends CI_Controller {

	function __construct(){
		parent::__construct();              
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->helper('security');
		$this->load->model('data_model');  
	}

	public function index()
	{
		$data['runningtext']= $this->data_model->getData('runningtext');
		$data['pegawai']= $this->data_model->getData('pegawai');
		$data['infokeracunan']= $this->data_model->getData('infokeracunan');
		$data['iklan']= $this->data_model->getData('wmiklan');
		$this->load->view('index',$data);

	}

	public function ADDruntext(){
		$data = array(
			'TEXT' => $this->input->post('textrun'),
			'DATE_START' => $this->input->post('startrun'),
			'DATE_END' => $this->input->post('endrun')
			);
		if($this->data_model->post('runningtext',$data)){
			$message = "Running Text telah ditambahkan";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmruntext', 'refresh');
		}
		else{
			$message = "terjadi kesalahan pada database";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmruntext', 'refresh');
		}
	}
	public function ADDinfokeracunan(){

		
		if($_FILES["fileToUpload"]["name"]){
			$data = array(
				'NAMAFILE' => $_FILES["fileToUpload"]["name"]
				);
			$target_dir = "image/";
			$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
			if(isset($_POST["submit"])) {
				$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				if($check !== false) {
					echo "File is an image - " . $check["mime"] . ".";
					$uploadOk = 1;
				} else {
					echo "File is not an image.";
					$uploadOk = 0;
				}
			}
// Check if file already exists
			if (file_exists($target_file)) {
				echo "Sorry, file already exists.";
				$uploadOk = 0;
			}
// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "JPG" && $imageFileType != "PNG") {
				echo "Sorry, only JPG and PNG files are allowed.";
				$uploadOk = 0;
			}
// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				$message = "Sorry, your file was not uploaded.";
				echo "<script type='text/javascript'>alert('$message');</script>";
// if everything is ok, try to upload file
			} else {
				if ($this->data_model->post('infokeracunan',$data) && move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir.''.basename( $_FILES["fileToUpload"]["name"]))) {
					$message = "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
					echo "<script type='text/javascript'>alert('$message');</script>";

				} else {
					$message = "terjadi kesalahan, upload gagal";
					echo "<script type='text/javascript'>alert('$message');</script>";
				}
			}
		}
		else{
			$message = "Tidak ada file yang di pilih";
			echo "<script type='text/javascript'>alert('$message');</script>";
		}
		redirect('coma?page=kioskkeracunan', 'refresh');
	}

	public function deleteinfokeracunan(){
		$id=$this->input->get('var1');
		$name=$this->input->get('var2');
		$path="image/".$name;
		if($this->data_model->delete('infokeracunan',$id)){
			if (file_exists($path)) {
				unlink($path);
			}
			$message = "image ".$name." telah di hapus";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=kioskkeracunan', 'refresh');
		}
		else{
			$message = "terjadi kesalahan pada database";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=kioskkeracunan', 'refresh');
		}
	}
	public function deleteiklan(){
		$id=$this->input->get('var1');
		$name=$this->input->get('var2');
		$path="video/".$name;
		if($this->data_model->delete('wmiklan',$id)){
			if (file_exists($path)) {
				unlink($path);
			}
			$message = "video ".$name." telah di hapus";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmiklan', 'refresh');
		}
		else{
			$message = "terjadi kesalahan pada database";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmiklan', 'refresh');
		}
	}


	public function updatePegawai(){
		$id=$this->input->get('var1');
		$i=$this->input->get('var2');
		$data = array(
			'NAMA' => $this->input->post('nama'),
			'KANTOR' => $this->input->post('alamat'),
			'PENDIDIKAN' => $this->input->post('pendidikan'),
			'KARIR' => $this->input->post('karir'),
			);
		if($this->data_model->edit('pegawai',$id,$data)){
			if($_FILES["fileToUpload".$i.""]["name"]){
				$target_dir = "image/";
				$target_file = $target_dir . basename($_FILES["fileToUpload".$i.""]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
				if(isset($_POST["submit"])) {
					$check = getimagesize($_FILES["fileToUpload".$i.""]["tmp_name"]);
					if($check !== false) {
						echo "File is an image - " . $check["mime"] . ".";
						$uploadOk = 1;
					} else {
						echo "File is not an image.";
						$uploadOk = 0;
					}
				}

// Allow certain file formats
				if($imageFileType != "jpg" ) {
					echo "Sorry, only JPG allowed.";
					$uploadOk = 0;
				}
				// Check if file already exists
				if (file_exists($target_dir.''.$id.'.jpg')) {
					unlink($target_dir.''.$id.'.jpg');
				}
// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
					echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
				} else {
					if (move_uploaded_file($_FILES["fileToUpload".$i.""]["tmp_name"], $target_dir.''.$id.'.jpg')) {
						echo "The file ". basename( $_FILES["fileToUpload".$i.""]["name"]). " has been uploaded.";
					} else {
						echo "Sorry, there was an error uploading your file.";
					}
				}
			}
			if($_FILES["fileToUpload".$i."gedung"]["name"]){
				$target_dir = "image/";
				$target_file = $target_dir . basename($_FILES["fileToUpload".$i."gedung"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
				if(isset($_POST["submit"])) {
					$check = getimagesize($_FILES["fileToUpload".$i."gedung"]["tmp_name"]);
					if($check !== false) {
						echo "File is an image - " . $check["mime"] . ".";
						$uploadOk = 1;
					} else {
						echo "File is not an image.";
						$uploadOk = 0;
					}
				}
// Check if file already exists
				if (file_exists($target_dir.''.$id.'_gedung.jpg')) {
					unlink($target_dir.''.$id.'_gedung.jpg');
				}
// Allow certain file formats
				if($imageFileType != "jpg" ) {
					echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
					$uploadOk = 0;
				}
// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
					echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
				} else {
					if (move_uploaded_file($_FILES["fileToUpload".$i."gedung"]["tmp_name"], $target_dir.''.$id.'_gedung.jpg')) {
						echo "The file ". basename( $_FILES["fileToUpload".$i."gedung"]["name"]). " has been uploaded.";
					} else {
						echo "Sorry, there was an error uploading your file.";
					}
				}
			}
			$message = "Profile Telah di Update";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=profilepegawai', 'refresh');
		}
	}
	public function uploadvideo($id){
		if($_FILES["fileToUpload"]["name"]){
			$target_dir = "video/";
			$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image

// Check if file already exists
			if (file_exists($target_dir.''.$id.'.mp4')) {
				unlink($target_dir.''.$id.'.mp4');
			}
// Check file size
			if ($_FILES["fileToUpload"]["size"] > 256000000) {
				echo "Sorry, your file is too large.";

				$uploadOk = 0;
				echo "Sorry, there was an error uploading your file.";
				$message = "failed to Upload";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma', 'refresh');
			}
// Allow certain file formats
			if($imageFileType != "mp4" ) {
				echo "Sorry, only mp4 files are allowed.";
				
				$uploadOk = 0;
				echo "Sorry, there was an error uploading your file.";
				$message = "failed to Upload";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma', 'refresh');
			}
// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
				echo "Sorry, there was an error uploading your file.";
				$message = "failed to Upload";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma', 'refresh');
// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir.''.$id.'.mp4')) {
					echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
					$message = "Video Telah di Upload";
					echo "<script type='text/javascript'>alert('$message');</script>";
					redirect('coma', 'refresh');
				} else {
					echo "Sorry, there was an error uploading your file.";
					$message = "failed to Upload the Video";
					echo "<script type='text/javascript'>alert('$message');</script>";
					redirect('coma', 'refresh');
				}
			}

		}
	}

	public function ADDiklan(){
		$hari="";
		$link="http://localhost/signageadmin/video/";
		if(!empty($_POST['check_list'])){
			foreach($_POST['check_list'] as $selected){
				$hari="".$hari."".$selected.",";
			}
		}
		
		if($_FILES["fileToUpload"]["name"]){
			$data = array(
				'LINK' => "".$_FILES["fileToUpload"]["name"],
				'HARI' => "".$hari
				);
			$target_dir = "video/";
			$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			$uploadOk = 1;
			$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
			// Check if image file is a actual image or fake image

			if($imageFileType != "mp4" ) {
				echo "Sorry, only mp4 files are allowed.";

				$uploadOk = 0;
				echo "Sorry, there was an error uploading your file.";
				$message = "failed to Upload";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma?page=wmiklan', 'refresh');
			}
// Check if file already exists
			if (file_exists($target_dir.''.$_FILES["fileToUpload"]["name"])) {
				$message = "Video dengan nama yang sama sudah ada";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma?page=wmiklan', 'refresh');
			}
// Check file size
			if ($_FILES["fileToUpload"]["size"] > 256000000) {
				echo "Sorry, your file is too large.";

				$uploadOk = 0;
				echo "Sorry, there was an error uploading your file.";
				$message = "failed to Upload";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma?page=wmiklan', 'refresh');
			}
// Allow certain file formats
			
// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded.";
				echo "Sorry, there was an error uploading your file.";
				$message = "failed to Upload";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma?page=wmiklan', 'refresh');
// if everything is ok, try to upload file
			} else {
				if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_dir.''.$_FILES["fileToUpload"]["name"])) {
					if($this->data_model->post('wmiklan',$data)){
						echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
						$message = "Video Berhasil di Upload";
						echo "<script type='text/javascript'>alert('$message');</script>";
						redirect('coma?page=wmiklan', 'refresh');
					}
					else{
						$message = "Terjadi kesalahan pada database";
						echo "<script type='text/javascript'>alert('$message');</script>";
						redirect('coma?page=wmiklan', 'refresh');
					}
					
				} else {
					echo "Sorry, there was an error uploading your file.";
					$message = "failed to Upload the Video";
					echo "<script type='text/javascript'>alert('$message');</script>";
					redirect('coma?page=wmiklan', 'refresh');
				}
			}

		}
		else{
			$message = "tidak ada video yang di upload";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmiklan', 'refresh');
		}
	}

	public function editAdmin(){
		if($this->data_model->checkData('admin',$this->input->post('oldusername'),$this->input->post('oldpassword'))){
			redirect('coma?page=change', 'refresh');
		}
		else{
			$message = "Username atau password salah";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=profil', 'refresh');
		}
	}
	public function changeAdmin(){
		if($this->input->post('newpassword')==$this->input->post('confirmnewpassword')){
			$data = array(
				'USERNAME' => $this->input->post('newusername'),
				'PASSWORD' => md5($this->input->post('newpassword'))
				);
			if($this->data_model->changeData('admin',$data)){
				$message = "Username dan password berhasil di ganti";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma?page=profil', 'refresh');
			}
			else{
				$message = "terjadi kesalahan pada database";
				echo "<script type='text/javascript'>alert('$message');</script>";
				redirect('coma?page=profil', 'refresh');
			}
		}
		else{
			$message = "password dan confirm password tidak cocok";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=change', 'refresh');
		}

	}
	public function deleteruntext($id){
		if($this->data_model->delete('runningtext',$id)){
			$message = "Runtext Telah di Hapus";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmruntext', 'refresh');
		}
		else{
			$message = "terjadi kesalahan pada database";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma?page=wmruntext', 'refresh');
		}
	}

	function logout()
	{
		$sess_array = array(
			'type',
			'username'
			);
		$this->session->unset_userdata($sess_array);
		$this->session->sess_destroy();
		redirect('coma', 'refresh');
	}

	public function loginAdmin(){
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','Username','trim|required|xss_clean');
		$this->form_validation->set_rules('password','Password','trim|required|xss_clean|callback_check_Admin');
		if($this->form_validation->run() == FALSE)
		{

			$message = "Username atau Password salah";
			echo "<script type='text/javascript'>alert('$message');</script>";
			redirect('coma', 'refresh');
		}
		else
		{
			redirect('coma', 'refresh');
		}
	}

	function check_Admin($password)
	{
		$result=$this->data_model->login('admin',$this->input->post('username'),$password);
		if($result)
		{
			$sess_array = array();
			foreach($result as $row)
			{
				$sess_array = array(
					'type' => 'admin',
					'username' => $row->username
					);
				$this->session->set_userdata($sess_array);
			}
			return TRUE;
		}
		else
		{
			$this->form_validation->set_message('check_Admin', 'Invalid username or password');
			return false;
		}
	}




}

