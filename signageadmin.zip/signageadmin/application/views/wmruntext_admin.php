<div class="well" id="main-content">
  <div class="row-fluid">
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#ADDBukuModal">ADD Text</button>
    <!-- Modal ADD-->
    <div class="modal fade" id="ADDBukuModal" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Tambah Running Text</h4>
          </div>
          <div class="modal-body">
            <form action="<?php echo base_url('index.php/coma/ADDruntext');?>" method="post" enctype="multipart/form-data">
              
              <div class="row-fluid">
                <div class="span12">

                  <table width="100%">
                    <tr>
                      <td>Input Text</td>
                      <td><textarea name="textrun" cols="40" rows="3" id="textrun"></textarea></td>
                      <!-- <td><input type="text" name="textrun" placeholder="Text"></td> -->
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>Tanggal Mulai</td>
                      <td><input id="datepicker1"name="startrun"></td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>Tanggal Selesai</td>
                      <td><input id="datepicker2"name="endrun"></td>
                      
                    </tr>
                  </table>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-info" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>

                </div>
              </div><!--row-->
            </form>
          </div>

        </div>
      </div>
    </div>
    <!--Modal ADD-->

    <table border="1" class="table-condensed table-striped" bordercolor='#ffffff' width="100%">
      <?php
      if($runningtext != NULL)
      {
        $i=0;
        foreach ($runningtext as $key) 
        {
          ?>
          <tr >
            <td ><?php $rest = substr($key->text,0,50);echo $rest;?></td>
            <td rowspan="2" class="btndetail"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal<?php echo $i?>">detail</button></td> 
            <td rowspan="2" class="btndetail"><a href='<?php echo base_url("index.php/coma/deleteruntext/$key->idrunningtext");?>'><input type='submit' value='Delete' class="btn btn-info" onClick='return doconfirm();'></a></td>
          </tr>
          

          <tr>

            <td>
              <!-- Modal detail -->
              <div class="modal fade" id="myModal<?php echo $i?>" role="dialog">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title">no. ID : <?php echo $key->idrunningtext;?></h4>
                    </div>
                    <div class="modal-body">
                      <div class="row-fluid">
                        <div class="span7 title">
                          <table class="table table-condensed">
                            <tbody>
                              <tr>
                                <td>Text:</td>
                                <td><?php echo $key->text;?></td>
                              </tr>
                              <tr>
                                <td>Tanggal Mulai:</td>
                                <td><?php echo $key->date_start;?></td>
                              </tr>
                              <tr>
                                <td>Tanggal Selesai:</td>
                                <td><?php echo $key->date_end;?></td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              <!--modal detail-->
            </td>
              </tr>
              <?php $i++;}
            }
            ?>
          </table>

        </div><!--/row-->
      </div><!--/span-->

<script>
  $(function() {
    $( "#datepicker1" ).datepicker({ dateFormat: 'yy-mm-dd' });
    $( "#datepicker2" ).datepicker({ dateFormat: 'yy-mm-dd' });
  });

</script>
    </body>
    </html>
