<?php 
if(isset($_GET['page']))
    $page=$_GET['page'];
if($this->session->userdata('type'))
    $type = $this->session->userdata('type');

?>
<html>
<head>
    <title>Admin BPOM</title>
</head>
<body style="background: #D9D9D9;">

    <link href = "<?php echo base_url(); ?>/css/main.css" rel="stylesheet" type="text/css" />
    <link href = "<?php echo base_url(); ?>/css/bootstrap.css" rel="stylesheet" type="text/css" />
    <script src="<?php echo base_url(); ?>/js/jquery-1.11.3.min.js"></script>
    <script src="<?php echo base_url(); ?>/js/bootstrap.js"></script>
    <script src="<?php echo base_url(); ?>/ckeditor/ckeditor.js"></script>

     <link rel="stylesheet" href="<?php echo base_url(); ?>/css/jquery-ui.css"> 
    <script src="<?php echo base_url(); ?>/js/jquery-ui.js"></script>

    <script>
    function doconfirm()
    {
        job=confirm("Are you sure to delete permanently?");
        if(job!=true)
        {
            return false;
        }
    }
    </script>

    <div class="container">

        <!--HEAD-->
        <?php
        if(!isset($type)){

            $this->load->view('login');
        }
        else{

        $this->load->view('head_'.$type.'');//head of admin
        $this->load->view('nav_'.$type.'');// navbar admin
        if(!isset($page)){
            $this->load->view('main_'.$type.''); //menu utama
        }
        else{
            $this->load->view(''.$page.'_'.$type.'');//menu pilihan
        }
        $this->load->view('footer_'.$type.'');//footer
    }
    ?>

</div>


</body>
<script src="<?php echo base_url(); ?>/js/main.js"></script>

</html>
