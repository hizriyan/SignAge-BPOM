<?php
$today = date("Y-m-d");
if($this->session->userdata('username'))
  $username = $this->session->userdata('username');
if(isset($_GET['hal']))
  $hal=$_GET['hal'];
if(isset($_GET['page']))
  $page=$_GET['page'];
?>
<div class="well" id="main-content"style="height:500px;">
  <div class="row-fluid">
  </div>
</div><!--/span-->

