<div class="well" id="main-content">
  <div class="row-fluid">

    <!-- Edit Profile-->

      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Input New Username dan Password</h4>
          </div>
          <div class="modal-body">
            <form action="<?php echo base_url('index.php/coma/changeAdmin');?>" method="post" enctype="multipart/form-data">
              
              <div class="row-fluid">
                <div class="span12">
                  <table width="100%">
                    <tr>
                      <td>Input new Username</td>
                      <td><input type="text" name="newusername" placeholder="username"></td>
                    </tr>
                    <tr>
                      <td>Input new Password</td>
                      <td><input type="password" name="newpassword" placeholder="*****"></td>
                    </tr>
                    <tr>
                      <td>Confirm new Password</td>
                      <td><input type="password" name="confirmnewpassword" placeholder="*****"></td>
                    </tr>
                  </table>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-info" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>

                </div>
              </div><!--row-->
            </form>
          </div>

        </div>
      </div>
    <!--Edit Profile-->

        </div><!--/row-->
      </div><!--/span-->


    </body>
    </html>
