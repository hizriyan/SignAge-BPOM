

<div style="width:600px;height:200px;background:white;position:absolute;top:250px;left:400px;box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
  <div>
    <img src="<?php echo base_url()?>/image/header.png" style="width:400px; height:200px;position:absolute;"></img>
  </div>
  <div>
    <form  method="post" action="<?php echo base_url('index.php/coma/loginAdmin');?>" id="form" style="width:200px;height:200px;padding-top:40px;padding-left:10px;background:white;position:absolute;left:400px;">
      <div class="form-group">
        <input name="username" id="username" type="text" value="" placeholder="Username"  >
      </div>
      <div class="form-group">
        <input name="password" id="password" type="password" value="" placeholder="Password"  >
      </div>
      <div class="form-group">
        <button class="btn btn-primary">Sign In</button>
      </div>
    </form>
  </div>
</div>
