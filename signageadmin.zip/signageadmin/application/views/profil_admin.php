<div class="well" id="main-content">
  <div class="row-fluid">

    <!-- Edit Profile-->

      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Edit Username Admin dan Password</h4>
          </div>
          <div class="modal-body">
            <form action="<?php echo base_url('index.php/coma/editAdmin');?>" method="post" enctype="multipart/form-data">
              
              <div class="row-fluid">
                <div class="span12">
                  <table width="100%">
                    <tr style="padding-bottom:10px;">
                      <td>Input old Username</td>
                      <td><input type="text" name="oldusername" placeholder="username"></td>
                    </tr>
                    <tr>
                      <td>Input old Password</td>
                      <td><input type="password" name="oldpassword" placeholder="*****"></td>
                    </tr>
                  </table>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-info" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>

                </div>
              </div><!--row-->
            </form>
          </div>

        </div>
      </div>
    <!--Edit Profile-->

        </div><!--/row-->
      </div><!--/span-->


    </body>
    </html>
