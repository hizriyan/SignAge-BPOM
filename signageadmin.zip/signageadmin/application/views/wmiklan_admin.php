<?php
$today = date("Y-m-d");
if($this->session->userdata('username'))
  $username = $this->session->userdata('username');
if(isset($_GET['hal']))
  $hal=$_GET['hal'];
if(isset($_GET['page']))
  $page=$_GET['page'];
?>
<div class="well" id="main-content">
  <div class="row-fluid">
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#ADDiklanmodal">Tambah Iklan</button>
    <!-- Modal ADD-->
    <div class="modal fade" id="ADDiklanmodal" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Tambah Video</h4>
          </div>
          <div class="modal-body">
            <form action="<?php echo base_url('index.php/coma/ADDiklan');?>" method="post" enctype="multipart/form-data">
              <div class="row-fluid">
                Select video to upload:
                <input type="file" name="fileToUpload" id="fileToUpload"></br></br>

                Hari pemutaran video:
                <table style="width:100%;">
                  <tr>
                    <td><input type="checkbox" name="check_list[]" value="1"><label>Senin</label></td>
                    <td><input type="checkbox" name="check_list[]" value="2"><label>Selasa</label></td>
                    <td><input type="checkbox" name="check_list[]" value="3"><label>Rabu</label></td>
                    <td><input type="checkbox" name="check_list[]" value="4"><label>Kamis</label></td>
                  </tr>
                  <tr>
                    <td><input type="checkbox" name="check_list[]" value="5"><label>Jumat</label></td>
                    <td><input type="checkbox" name="check_list[]" value="6"><label>Sabtu</label></td>
                    <td><input type="checkbox" name="check_list[]" value="7"><label>Minggu</label></td>
                    <td>&nbsp;</td>
                  </tr>
                </table>
                
                
                
                <br/>
                
                
                
              </div>
              <div class="row-fluid">
                <div class="span12">
                  <div class="modal-footer">
                    <input type="submit"  value="Upload Video" class="btn btn-info" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>

                </div>
              </div><!--row-->
            </form>
          </div>

        </div>
      </div>
    </div>
    <!--Modal ADD-->

    <table border="1" class="table-condensed table-striped" bordercolor='#ffffff' width="100%">
      <?php
      if($iklan != NULL)
      {
        $i=0;
        foreach ($iklan as $key) 
        {
          ?>
          <tr >

            <td><?php echo $key->link;?></td>
            
            
            <td rowspan="2" class="btndetail"><a href='<?php echo base_url("index.php/coma/deleteiklan?var1=".$key->idiklan."&var2=".$key->link."");?>'>
              <input type='submit' value='Delete' class="btn btn-info" onClick='return doconfirm();'></a></td>
            </tr>
            <tr>
              <td style="font-size:15px;"><?php 
              $day="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;hari tayang: ";
              if (strpos($key->hari,'1') !== false) {
                $day="".$day."Senin, ";
              }
              if (strpos($key->hari,'2') !== false) {
                $day="".$day."Selasa, ";
              }
              if (strpos($key->hari,'3') !== false) {
                $day="".$day."Rabu, ";
              }
              if (strpos($key->hari,'4') !== false) {
                $day="".$day."Kamis, ";
              }
              if (strpos($key->hari,'5') !== false) {
                $day="".$day."Jumat, ";
              }
              if (strpos($key->hari,'6') !== false) {
                $day="".$day."Sabtu, ";
              }
              if (strpos($key->hari,'7') !== false) {
                $day="".$day."Minggu, ";
              }
              echo $day;
              ?></td>
            </tr>
            <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
            <?php $i++;}
          }
          ?>
        </table>

      </div><!--/row-->
    </div><!--/span-->

  </body>
  </html>
