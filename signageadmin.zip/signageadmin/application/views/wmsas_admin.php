<?php
$today = date("Y-m-d");
if($this->session->userdata('username'))
  $username = $this->session->userdata('username');
if(isset($_GET['hal']))
  $hal=$_GET['hal'];
if(isset($_GET['page']))
  $page=$_GET['page'];
?>
<div class="well " id="main-content">
  <div class="row-fluid">
    <div class="modal-dialog span12">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Wallmount SAS</h4>
        </div>
        <div class="modal-body ">
          <form action="<?php echo base_url();?>/index.php/coma/uploadvideo/sas" method="post" enctype="multipart/form-data">
            Select video to upload:
            <input type="file" name="fileToUpload" id="fileToUpload">
            <input type="submit" value="Upload Video" name="submit">
          </form>
        </div>
      </div>
    </div>
  </div>
</div><!--/span-->

<script>

</script>
</body>
</html>
