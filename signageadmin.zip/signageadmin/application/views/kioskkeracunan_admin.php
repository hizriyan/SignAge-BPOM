<?php
$today = date("Y-m-d");
if($this->session->userdata('username'))
  $username = $this->session->userdata('username');
if(isset($_GET['hal']))
  $hal=$_GET['hal'];
if(isset($_GET['page']))
  $page=$_GET['page'];
?>
<div class="well" id="main-content">
  <div class="row-fluid">
    <button type="button" class="btn btn-info" data-toggle="modal" data-target="#ADDinfomodal">ADD Info</button>
    <!-- Modal ADD-->
    <div class="modal fade" id="ADDinfomodal" role="dialog">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Tambah Info Keracunan</h4>
          </div>
          <div class="modal-body">
            <form action="<?php echo base_url('index.php/coma/ADDinfokeracunan');?>" method="post" enctype="multipart/form-data">
              <div class="row-fluid">
                <div class="span4">
                  <p><img id="imageprev"src="<?php echo base_url(); ?>/image/no_image.jpg" class="img-polaroid img"></p>
                </div>
                <div class="span7 title">
                  <input type="file" name="fileToUpload" id="fileToUpload">
                </div>
              </div>
              <div class="row-fluid">
                <div class="span12">
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-info" value="Submit">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>

                </div>
              </div><!--row-->
            </form>
          </div>

        </div>
      </div>
    </div>
    <!--Modal ADD-->

    <table border="1" class="table-condensed table-striped" bordercolor='#ffffff' width="100%">
      <?php
      if($infokeracunan != NULL)
      {
        $i=0;
        foreach ($infokeracunan as $key) 
        {
          ?>
          <tr >
            <td rowspan="2" class="gambar"><img src="<?php echo ''.base_url().'/image/'.$key->namafile.'';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid imgicon"></td>
            <td><?php echo $key->namafile;?></td>
            <td rowspan="2" class="btndetail"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal<?php echo $i?>">detail</button></td>
            <td rowspan="2" class="btndetail"><a href='<?php echo base_url("index.php/coma/deleteinfokeracunan?var1=".$key->idkeracunan."&var2=".$key->namafile."");?>'><input type='submit' value='Delete' class="btn btn-info" onClick='return doconfirm();'></a></td>
          </tr>

          <tr>












            <td>
              <!-- Modal detail -->
              <div class="modal fade" id="myModal<?php echo $i?>" role="dialog">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title"><?php echo $key->namafile;?></h4>
                    </div>
                    <div class="modal-body">
                      <div class="row-fluid ">
                        <div class="span4">
                          <p><img src="<?php echo ''.base_url().'/image/'.$key->namafile.'';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid imgracun"></p>
                        </div>
                      </div>


                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              <!--modal detail-->
            </td>
          </td>
        </tr>
        <?php $i++;}
      }
      ?>
    </table>

  </div><!--/row-->
</div><!--/span-->

<script>
  $(function () {
    $("#fileToUpload").change(function () {
      if (this.files && this.files[0]) {
        var reader = new FileReader();
        reader.onload = imageIsLoaded<?php echo $i;?>;
        reader.readAsDataURL(this.files[0]);
      }
    });
  });

  function imageIsLoaded(e) {
    $('#imageprev').attr('src', e.target.result);
  };

  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
        $('#imageprev').attr('src', e.target.result);
      }

      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#fileToUpload").change(function(){
    readURL(this);
  });
  </script>
</body>
</html>
