<!--NAV 1-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <ul class="nav navbar-nav">
      <li class=""><a href="<?php echo base_url('');?>">Home</a></li>
      <li class="dropdown" role="menu"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Wallmount<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="?page=wmsas">Viedo SAS</a></li>
          <li><a href="?page=wmkeracunan">Video Keracunan</a></li>
          <li><a href="?page=wmiklan">Video Iklan</a></li>
          <li><a href="?page=wmruntext">Running Text</a></li>
        </ul>
      </li>
      <li class=""><a href="?page=profilepegawai">Profile Pegawai</a></li>
      <li class="dropdown" role="menu"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Kiosk<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="?page=kioskkeracunan">Slide Keracunan</a></li>
        </ul>
      </li>
      <li class="dropdown" style="margin-left:640px;" role="menu"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Setting<span class="caret"></span></a>
        <ul class="dropdown-menu pull-right">
          <li><a href="?page=profil">Edit Admin</a></li>
          <li><a href="<?php echo base_url("index.php/coma/logout");?>">Log Out</a></li>
        </ul>
      </li>
    </ul>
  </div>
</nav>
