<?php
$today = date("Y-m-d");
if($this->session->userdata('username'))
  $username = $this->session->userdata('username');
if(isset($_GET['hal']))
  $hal=$_GET['hal'];
if(isset($_GET['page']))
  $page=$_GET['page'];
?>
<div class="well" id="main-content">
  <div class="row-fluid">

    <div style="width:100%;height:50px;margin-left:500px;">
      <?php if(isset($_GET['hal']) && $hal==1){ ?>
      <a href="?page=profilepegawai&hal=1"><input type="button" class="btn btn-info active"  value="1"/></a>
      <a href="?page=profilepegawai&hal=2"><input type="button" class="btn btn-info" value="2"/></a>
      <?php }
      elseif (isset($_GET['hal']) && $hal==2) { ?>
      <a href="?page=profilepegawai&hal=1"><input type="button" class="btn btn-info "  value="1"/></a>
      <a href="?page=profilepegawai&hal=2"><input type="button" class="btn btn-info active" value="2"/></a>
      <?php }
      else{ ?>
      <a href="?page=profilepegawai&hal=1"><input type="button" class="btn btn-info active"  value="1"/></a>
      <a href="?page=profilepegawai&hal=2"><input type="button" class="btn btn-info" value="2"/></a>
      <?php } ?>
    </div>

    <table border="1" class="table-condensed table-striped" bordercolor='#ffffff' width="100%">
      <?php
      if($pegawai != NULL)
      {
        if(isset($_GET['hal'])){

          $hal=$_GET['hal'];
          $max=$hal*sizeof($pegawai)/2;
          $count=floor(($hal-1)*sizeof($pegawai)/2);
        }
        else{
          $max=(sizeof($pegawai)/2);  
          $count=0;
        }
        $i=0;
        foreach ($pegawai as $key) 
        {
          if($i>=$count && $i<$max){
            ?>
            <tr >
              <td rowspan="2" class="gambar"><img src="<?php echo ''.base_url().'/image/'.$key->idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid imgicon"></td>
              <td><?php echo $key->jabatan;?></td>
              <td rowspan="2" class="btndetail"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal<?php echo $i?>">detail</button></td>
              <td rowspan="2" class="btndetail"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#Editbukumodal<?php echo $i?>">Edit</button></td>
            </tr>
            <tr>
              <td><?php echo $key->nama;?></td>
            </tr>

            <tr>



              <td>
                <!-- Modal detail -->
                <div class="modal fade" id="myModal<?php echo $i?>" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><?php echo $key->jabatan;?></h4>
                      </div>
                      <div class="modal-body">
                        <div class="row-fluid">
                          <div class="span4">
                            <p>Profile Picture</p>
                            <p><img src="<?php echo ''.base_url().'image/'.$key->idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid img"></p>
                          </div>
                          <div class="span4">
                            <p>Gedung</p>
                            <p><img src="<?php echo ''.base_url().'image/'.$key->idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid img"></p>
                          </div>
                          <div class="span7 title">
                            <table class="table table-condensed">
                              <thead>
                                <tr>
                                  <th width="20%"></th>
                                  <th></th>
                                </tr>
                              </thead>
                              <tbody>
                                <tr>
                                  <td>Nama:</td>
                                  <td><?php echo $key->nama;?></td>
                                </tr>
                                <tr>
                                  <td>Alamat:</td>
                                  <td><?php echo $key->kantor;?></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <hr />
                        <div class="row-fluid">
                          <div class="span12">
                            <p class="title">
                              <strong>Pendidikan : </strong>
                            </p>
                            <p class="title">
                              <?php echo $key->pendidikan;?>
                            </p>
                          </div>
                        </div><!--row-->
                        <hr />

                        <div class="row-fluid">
                          <div class="span12">
                            <p class="title">
                              <strong>Karir : </strong>
                            </p>
                            <p class="title">
                              <?php echo $key->karir;?>
                            </p>
                          </div>
                        </div><!--row-->
                      </div><!--row-->

                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                  </div>
                </div>
              </div>
              <!--modal detail-->
            </td>




            <td>
              <!-- Modal Edit -->
              <div class="modal fade" id="Editbukumodal<?php echo $i?>" role="dialog">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal">&times;</button>
                      <h4 class="modal-title"><?php echo $key->jabatan;?></h4>
                    </div>
                    <div class="modal-body">
                      <form action="<?php echo base_url('index.php/coma/updatePegawai?var1='.$key->idjabatan.'&var2='.$i.'');?>" method="post" enctype="multipart/form-data">
                        <div class="row-fluid">
                          <div class="span4">
                            <p>
                              <img id="imageprev<?php echo $i?>" src="<?php echo ''.base_url().'/image/'.$key->idjabatan.'.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid img">
                            </p>
                          </div>
                          <div class="span7 title">
                            <p style="font-weight:bold;" >Profile Picture</p>
                            <input type="file" name="fileToUpload<?php echo $i?>" id="fileToUpload<?php echo $i?>">
                          </div>
                        </div>
                        <div class="row-fluid">
                          <div class="span4">
                            <p>
                              <img id="imageprev<?php echo $i?>gedung" src="<?php echo ''.base_url().'/image/'.$key->idjabatan.'_gedung.jpg';?>" onError="this.src = '<?php echo base_url(); ?>/image/no_image.jpg'" class="img-polaroid img">
                            </p>
                          </div>
                          <div class="span7 title">
                            <p style="font-weight:bold;" >Gedung</p>
                            <input type="file" name="fileToUpload<?php echo $i?>gedung" id="fileToUpload<?php echo $i?>gedung">
                          </div>
                        </div>

                        <div class="row-fluid">
                          <div class="span12">
                            <table width="100%">
                              <tr >
                                <td style="font-weight:bold;" class = "isian" >Nama : </td>
                                <td><input type="text" name="nama" style="width:400px;" value="<?php echo $key->nama ?>"></td>
                              </tr>
                            </table>
                          </br>
                        </br>
                      </br>
                      <p style="font-weight:bold;" >Alamat : </p>
                      <textarea class="ckeditor" name="alamat"  id="alamat"><?php echo $key->kantor ?></textarea>
                      <p style="font-weight:bold;">Pendidikan :</p></br></br>
                      <textarea class="ckeditor" name="pendidikan"><?php echo $key->pendidikan ?></textarea>
                    </br>
                  </br>
                  <p style="font-weight:bold;">Karir :</p>
                  <textarea class="ckeditor" name="karir"><?php echo $key->karir ?></textarea>
                  <div class="modal-footer">
                    <input type="submit" class="btn btn-info" value="Save">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>

                </div>
              </div><!--row-->
              <hr />
            </form>
          </div>
        </div>
      </div>
    </div>
    <!--modal Edit-->

    <script>
    $(function () {
      $("#fileToUpload<?php echo $i;?>").change(function () {
        if (this.files && this.files[0]) {
          var reader = new FileReader();
          reader.onload = imageIsLoaded<?php echo $i;?>;
          reader.readAsDataURL(this.files[0]);
        }
      });
    });

    function imageIsLoaded<?php echo $i;?>(e) {
      $('#imageprev<?php echo $i;?>').attr('src', e.target.result);
    };

    function readURL<?php echo $i;?>(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
          $('#imageprev<?php echo $i;?>').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#fileToUpload<?php echo $i;?>").change(function(){
      readURL<?php echo $i;?>(this);
    });
    </script>
    <script>
    $(function () {
      $("#fileToUpload<?php echo $i;?>gedung").change(function () {
        if (this.files && this.files[0]) {
          var reader = new FileReader();
          reader.onload = imageIsLoaded<?php echo $i;?>gedung;
          reader.readAsDataURL(this.files[0]);
        }
      });
    });

    function imageIsLoaded<?php echo $i;?>gedung(e) {
      $('#imageprev<?php echo $i;?>gedung').attr('src', e.target.result);
    };

    function readURL<?php echo $i;?>gedung(input) {
      if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
          $('#imageprev<?php echo $i;?>gedung').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
      }
    }

    $("#fileToUpload<?php echo $i;?>gedung").change(function(){
      readURL<?php echo $i;?>gedung(this);
    });
    </script>



  </td>
</tr>
<?php }$i++;}
}
?>
</table>
<div style="width:100%;height:50px;margin-left:500px;">
      <?php if(isset($_GET['hal']) && $hal==1){ ?>
      <a href="?page=profilepegawai&hal=1"><input type="button" class="btn btn-info active"  value="1"/></a>
      <a href="?page=profilepegawai&hal=2"><input type="button" class="btn btn-info" value="2"/></a>
      <?php }
      elseif (isset($_GET['hal']) && $hal==2) { ?>
      <a href="?page=profilepegawai&hal=1"><input type="button" class="btn btn-info "  value="1"/></a>
      <a href="?page=profilepegawai&hal=2"><input type="button" class="btn btn-info active" value="2"/></a>
      <?php }
      else{ ?>
      <a href="?page=profilepegawai&hal=1"><input type="button" class="btn btn-info active"  value="1"/></a>
      <a href="?page=profilepegawai&hal=2"><input type="button" class="btn btn-info" value="2"/></a>
      <?php } ?>
    </div>
</div><!--/row-->
</div><!--/span-->


</body>
</html>
