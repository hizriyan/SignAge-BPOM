<div class="jumbotron well" style="background:white;opacity:0.8;">
	<img src="<?php echo base_url(); ?>/image/header.png" class="">
	<!-- <a href='<?php echo base_url("index.php/coma/logout");?>'><input type='submit' value='LOGOUT' class="btn btn-info logout" ></a>       -->
</div>